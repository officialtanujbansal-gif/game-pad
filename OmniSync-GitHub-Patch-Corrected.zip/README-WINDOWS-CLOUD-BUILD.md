# OmniSync Bridge — corrected Windows cloud-build patch

Apply the four project files to the root of `officialtanujbansal-gif/game-pad` on `main`, preserving the folder paths:

- `package.json` (replace)
- `server.ts` (replace)
- `electron/main.cjs` (new)
- `.github/workflows/build-windows.yml` (new)

## Corrections included

- The server bundle lives under `dist-server/`, so the renderer path is supplied explicitly with `APP_DIST_DIR`.
- The existing controller HTML asset is supplied through `APP_PUBLIC_DIR` and packaged from `public/`.
- Sync data is stored under Electron's per-user app-data directory.
- Electron Builder resolves production dependencies from `package.json` instead of copying the entire development `node_modules` tree.

## Cloud build

After committing the files, open **Actions → Build OmniSync Bridge for Windows → Run workflow**. The `OmniSync-Bridge-Windows` artifact should contain the NSIS installer and portable Windows x64 executable if the build completes successfully.

## Python / driver note

The repository's Python receiver is kept as a companion asset and remains available to the existing download/launcher routes. This patch does not silently install Python packages or the ViGEmBus kernel driver. The receiver and driver still need their supported Windows setup.

The workflow has not yet been run; inspect its logs and test both EXEs on Windows before relying on them.
